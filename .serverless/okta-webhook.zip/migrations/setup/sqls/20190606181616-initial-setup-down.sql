DROP USER 'starter-kit'@'localhost';
