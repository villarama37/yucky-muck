DROP USER 'starter-kit'@'localhost' IDENTIFIED BY '3k293cp0tjnMq';
