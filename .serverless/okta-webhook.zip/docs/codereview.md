Is there any unescaped / improperly escaped input being passed to SQL, RegExp, and other interpreters?
Are all error conditions caught, handled, and reported to the error log?
Are unit tests updated for new or changed functionality?
